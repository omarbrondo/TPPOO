package Buquealtoque;

public abstract class Pago {
    public abstract void realizarPago(double monto);
}
